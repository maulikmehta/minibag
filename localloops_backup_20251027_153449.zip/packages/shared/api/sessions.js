/**
 * Sessions API Routes
 * Endpoints for creating and managing shopping sessions
 */

import { supabase } from '../db/supabase.js';
import crypto from 'crypto';

/**
 * Generate a short, unique session ID (6 chars)
 */
function generateSessionId() {
  return crypto.randomBytes(3).toString('hex'); // abc123
}

/**
 * 3-letter names for participant fallback (if pool is empty)
 */
const FALLBACK_NAMES = [
  // Hindi/Indian - Male
  'Raj', 'Avi', 'Tej', 'Ved', 'Jai', 'Adi', 'Dev', 'Sam', 'Sid', 'Vik',
  'Om', 'Yug', 'Nav', 'Arv', 'Mir',
  // Hindi/Indian - Female
  'Ria', 'Anu', 'Sia', 'Ira', 'Pia', 'Mia', 'Iva', 'Uma', 'Niv', 'Dia',
  'Eva', 'Ruh', 'Ara', 'Diy', 'Jia',
  // Gujarati - Male
  'Jay', 'Het', 'Mit', 'Vir', 'Nay', 'Ruj', 'Pax',
  // Gujarati - Female
  'Rit', 'Neh', 'Sar', 'Tia'
];

const AVATAR_EMOJIS = ['👨', '👩', '🧑', '👨‍🦱', '👩‍🦱', '👨‍🦰', '👩‍🦰', '👨‍🦲', '👩‍🦲'];

/**
 * Get 2 available nicknames from pool (1 male, 1 female)
 * Used to present options to user during join/create
 */
async function getTwoNicknameOptions() {
  // Get 1 male nickname
  const { data: maleOption, error: maleError } = await supabase
    .from('nicknames_pool')
    .select('*')
    .eq('is_available', true)
    .eq('gender', 'male')
    .limit(1)
    .single();

  // Get 1 female nickname
  const { data: femaleOption, error: femaleError } = await supabase
    .from('nicknames_pool')
    .select('*')
    .eq('is_available', true)
    .eq('gender', 'female')
    .limit(1)
    .single();

  // Prepare options array
  const options = [];

  if (!maleError && maleOption) {
    options.push({
      id: maleOption.id,
      nickname: maleOption.nickname,
      avatar_emoji: maleOption.avatar_emoji,
      gender: 'male'
    });
  }

  if (!femaleError && femaleOption) {
    options.push({
      id: femaleOption.id,
      nickname: femaleOption.nickname,
      avatar_emoji: femaleOption.avatar_emoji,
      gender: 'female'
    });
  }

  // If pool is running low, add fallback options
  if (options.length < 2) {
    const maleNames = FALLBACK_NAMES.filter((_, i) => i < 15); // First 15 are male
    const femaleNames = FALLBACK_NAMES.filter((_, i) => i >= 15); // Rest are female

    if (options.length === 0) {
      options.push({
        nickname: maleNames[Math.floor(Math.random() * maleNames.length)],
        avatar_emoji: '👨',
        gender: 'male',
        fallback: true
      });
    }

    options.push({
      nickname: femaleNames[Math.floor(Math.random() * femaleNames.length)],
      avatar_emoji: '👩',
      gender: 'female',
      fallback: true
    });
  }

  return options;
}

/**
 * Mark a nickname as used in the pool
 */
async function markNicknameAsUsed(nicknameId, sessionId) {
  if (!nicknameId) return; // Skip if fallback was used

  await supabase
    .from('nicknames_pool')
    .update({
      is_available: false,
      currently_used_in: sessionId,
      times_used: supabase.raw('times_used + 1'),
      last_used: new Date().toISOString()
    })
    .eq('id', nicknameId);
}

/**
 * Get an available nickname from the pool (LEGACY - for backward compatibility)
 */
async function getAvailableNickname(sessionId) {
  const { data, error } = await supabase
    .from('nicknames_pool')
    .select('*')
    .eq('is_available', true)
    .limit(1)
    .single();

  if (error || !data) {
    // Fallback if pool is empty - use random 3-letter name
    const randomName = FALLBACK_NAMES[Math.floor(Math.random() * FALLBACK_NAMES.length)];
    const randomEmoji = AVATAR_EMOJIS[Math.floor(Math.random() * AVATAR_EMOJIS.length)];
    return {
      nickname: randomName,
      avatar_emoji: randomEmoji
    };
  }

  // Mark as used
  await supabase
    .from('nicknames_pool')
    .update({
      is_available: false,
      currently_used_in: sessionId,
      times_used: data.times_used + 1,
      last_used: new Date().toISOString()
    })
    .eq('id', data.id);

  return {
    nickname: data.nickname,
    avatar_emoji: data.avatar_emoji
  };
}

/**
 * POST /api/sessions/create
 * Create a new shopping session
 */
export async function createSession(req, res) {
  try {
    const {
      location_text,
      neighborhood,
      scheduled_time,
      title,
      description,
      items = [], // Array of {item_id, quantity, unit}
      // New fields for nickname selection
      real_name,
      selected_nickname_id,
      selected_nickname,
      selected_avatar_emoji
    } = req.body;

    // Validation
    if (!location_text || !scheduled_time) {
      return res.status(400).json({
        success: false,
        error: 'location_text and scheduled_time are required'
      });
    }

    // Generate session ID
    const session_id = generateSessionId();

    // Get nickname - either from user selection or auto-assign
    let nickname, avatar_emoji;
    if (selected_nickname && selected_avatar_emoji) {
      // User selected a nickname from the options
      nickname = selected_nickname;
      avatar_emoji = selected_avatar_emoji;
    } else {
      // Fallback to old auto-assign flow (for backward compatibility)
      const nicknameData = await getAvailableNickname(session_id);
      nickname = nicknameData.nickname;
      avatar_emoji = nicknameData.avatar_emoji;
    }

    // Calculate expiry (2 hours after scheduled time)
    const expiresAt = new Date(scheduled_time);
    expiresAt.setHours(expiresAt.getHours() + 2);

    // Create session
    const { data: session, error: sessionError } = await supabase
      .from('sessions')
      .insert({
        session_id,
        session_type: 'minibag',
        creator_nickname: nickname,
        location_text,
        neighborhood,
        scheduled_time,
        expires_at: expiresAt.toISOString(),
        title,
        description,
        status: 'open'
      })
      .select()
      .single();

    if (sessionError) throw sessionError;

    // Mark nickname as used if it was selected from pool
    if (selected_nickname_id) {
      await markNicknameAsUsed(selected_nickname_id, session.id);
    }

    // Create participant (creator)
    const { data: participant, error: participantError} = await supabase
      .from('participants')
      .insert({
        session_id: session.id,
        nickname,
        avatar_emoji,
        real_name, // Store real name if provided
        is_creator: true
      })
      .select()
      .single();

    if (participantError) throw participantError;

    // Add items if provided
    if (items.length > 0) {
      // First, get the UUID for each item_id
      const itemIds = items.map(item => item.item_id);
      const { data: catalogItems, error: catalogError } = await supabase
        .from('catalog_items')
        .select('id, item_id')
        .in('item_id', itemIds);

      if (catalogError) throw catalogError;

      // Create a map of item_id -> UUID
      const itemIdMap = {};
      catalogItems.forEach(item => {
        itemIdMap[item.item_id] = item.id;
      });

      // Convert to database format with UUIDs
      const itemsToInsert = items.map(item => ({
        participant_id: participant.id,
        item_id: itemIdMap[item.item_id], // Use UUID instead of text
        quantity: item.quantity,
        unit: item.unit
      }));

      const { error: itemsError } = await supabase
        .from('participant_items')
        .insert(itemsToInsert);

      if (itemsError) throw itemsError;
    }

    res.json({
      success: true,
      data: {
        session: session,
        participant: participant,
        session_url: `/session/${session_id}`
      }
    });
  } catch (error) {
    console.error('Error creating session:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
}

/**
 * GET /api/sessions/:session_id
 * Get session details with participants and items
 */
export async function getSession(req, res) {
  try {
    const { session_id } = req.params;

    // Get session
    const { data: session, error: sessionError } = await supabase
      .from('sessions')
      .select('*')
      .eq('session_id', session_id)
      .single();

    if (sessionError) throw sessionError;

    if (!session) {
      return res.status(404).json({
        success: false,
        error: 'Session not found'
      });
    }

    // Get participants with their items
    const { data: participants, error: participantsError } = await supabase
      .from('participants')
      .select(`
        *,
        items:participant_items(
          *,
          catalog_item:catalog_items(*)
        )
      `)
      .eq('session_id', session.id);

    if (participantsError) throw participantsError;

    res.json({
      success: true,
      data: {
        session,
        participants
      }
    });
  } catch (error) {
    console.error('Error fetching session:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
}

/**
 * POST /api/sessions/:session_id/join
 * Join an existing session
 */
export async function joinSession(req, res) {
  try {
    const { session_id } = req.params;
    const {
      items = [], // Optional initial items
      // New fields for nickname selection
      real_name,
      selected_nickname_id,
      selected_nickname,
      selected_avatar_emoji
    } = req.body;

    // Get session
    const { data: session, error: sessionError } = await supabase
      .from('sessions')
      .select('*')
      .eq('session_id', session_id)
      .single();

    if (sessionError) throw sessionError;

    if (!session) {
      return res.status(404).json({
        success: false,
        error: 'Session not found'
      });
    }

    // Check if session is still open
    if (session.status !== 'open') {
      return res.status(400).json({
        success: false,
        error: 'Session is not accepting new participants'
      });
    }

    // Get nickname - either from user selection or auto-assign
    let nickname, avatar_emoji;
    if (selected_nickname && selected_avatar_emoji) {
      // User selected a nickname from the options
      nickname = selected_nickname;
      avatar_emoji = selected_avatar_emoji;
    } else {
      // Fallback to old auto-assign flow (for backward compatibility)
      const nicknameData = await getAvailableNickname(session.id);
      nickname = nicknameData.nickname;
      avatar_emoji = nicknameData.avatar_emoji;
    }

    // Mark nickname as used if it was selected from pool
    if (selected_nickname_id) {
      await markNicknameAsUsed(selected_nickname_id, session.id);
    }

    // Create participant
    const { data: participant, error: participantError } = await supabase
      .from('participants')
      .insert({
        session_id: session.id,
        nickname,
        avatar_emoji,
        real_name, // Store real name if provided
        is_creator: false
      })
      .select()
      .single();

    if (participantError) throw participantError;

    // Add items if provided
    if (items.length > 0) {
      // First, get the UUID for each item_id
      const itemIds = items.map(item => item.item_id);
      const { data: catalogItems, error: catalogError } = await supabase
        .from('catalog_items')
        .select('id, item_id')
        .in('item_id', itemIds);

      if (catalogError) throw catalogError;

      // Create a map of item_id -> UUID
      const itemIdMap = {};
      catalogItems.forEach(item => {
        itemIdMap[item.item_id] = item.id;
      });

      // Convert to database format with UUIDs
      const itemsToInsert = items.map(item => ({
        participant_id: participant.id,
        item_id: itemIdMap[item.item_id], // Use UUID instead of text
        quantity: item.quantity,
        unit: item.unit
      }));

      await supabase
        .from('participant_items')
        .insert(itemsToInsert);
    }

    res.json({
      success: true,
      data: {
        participant,
        session
      }
    });
  } catch (error) {
    console.error('Error joining session:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
}

/**
 * PUT /api/sessions/:session_id/status
 * Update session status
 */
export async function updateSessionStatus(req, res) {
  try {
    const { session_id } = req.params;
    const { status } = req.body;

    const validStatuses = ['open', 'active', 'shopping', 'completed', 'expired', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid status'
      });
    }

    const { data, error } = await supabase
      .from('sessions')
      .update({ status })
      .eq('session_id', session_id)
      .select()
      .single();

    if (error) throw error;

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Error updating session status:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
}

/**
 * GET /api/sessions/nickname-options
 * Get 2 available nickname options (1 male, 1 female) for user selection
 */
export async function getNicknameOptions(req, res) {
  try {
    const options = await getTwoNicknameOptions();

    res.json({
      success: true,
      data: options
    });
  } catch (error) {
    console.error('Error fetching nickname options:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
}

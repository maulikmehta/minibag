import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';

// API route imports
import * as catalogAPI from './api/catalog.js';
import * as sessionsAPI from './api/sessions.js';
import * as paymentsAPI from './api/payments.js';
import * as analyticsAPI from './api/analytics.js';

// Get current file directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load environment variables
dotenv.config({ path: resolve(__dirname, '../../.env') });

const app = express();
const server = createServer(app);

// Socket.IO setup
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    credentials: true
  }
});

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Basic routes
app.get('/', (req, res) => {
  res.json({
    message: 'LocalLoops API Server',
    version: '0.1.0',
    status: 'running'
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Catalog API routes
app.get('/api/catalog/categories', catalogAPI.getCategories);
app.get('/api/catalog/items', catalogAPI.getItems);
app.get('/api/catalog/items/:item_id', catalogAPI.getItem);
app.get('/api/catalog/popular', catalogAPI.getPopularItems);

// Sessions API routes
app.get('/api/sessions/nickname-options', sessionsAPI.getNicknameOptions);
app.post('/api/sessions/create', sessionsAPI.createSession);
app.get('/api/sessions/:session_id', sessionsAPI.getSession);
app.post('/api/sessions/:session_id/join', sessionsAPI.joinSession);
app.put('/api/sessions/:session_id/status', sessionsAPI.updateSessionStatus);

// Payments API routes
app.post('/api/sessions/:session_id/payments', paymentsAPI.recordPayment);
app.get('/api/sessions/:session_id/payments', paymentsAPI.getSessionPayments);
app.get('/api/sessions/:session_id/payments/summary', paymentsAPI.getPaymentSummary);
app.get('/api/sessions/:session_id/split', paymentsAPI.getPaymentSplit);
app.put('/api/payments/:payment_id', paymentsAPI.updatePayment);
app.delete('/api/payments/:payment_id', paymentsAPI.deletePayment);

// Analytics API routes
app.get('/api/analytics/overview', analyticsAPI.getAnalyticsOverview);
app.get('/api/analytics/sessions/weekly', analyticsAPI.getWeeklySessionTrends);
app.get('/api/analytics/revenue', analyticsAPI.getRevenueAnalytics);
app.get('/api/analytics/sessions/recent', analyticsAPI.getRecentSessions);

// WebSocket connection handling
io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  socket.on('join-session', (sessionId) => {
    socket.join(sessionId);
    console.log(`Client ${socket.id} joined session ${sessionId}`);
    io.to(sessionId).emit('user-joined', { socketId: socket.id });
  });

  socket.on('leave-session', (sessionId) => {
    socket.leave(sessionId);
    console.log(`Client ${socket.id} left session ${sessionId}`);
    io.to(sessionId).emit('user-left', { socketId: socket.id });
  });

  socket.on('session-update', (data) => {
    const { sessionId, update } = data;
    io.to(sessionId).emit('session-updated', update);
  });

  socket.on('payment-recorded', (data) => {
    const { sessionId, payment } = data;
    io.to(sessionId).emit('payment-updated', payment);
    console.log(`Payment recorded in session ${sessionId}:`, payment);
  });

  socket.on('payment-edited', (data) => {
    const { sessionId, payment } = data;
    io.to(sessionId).emit('payment-updated', payment);
    console.log(`Payment edited in session ${sessionId}:`, payment);
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

// Error handling
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Start servers
const API_PORT = process.env.API_PORT || 3000;
const WS_PORT = process.env.WEBSOCKET_PORT || 3001;

server.listen(WS_PORT, () => {
  console.log(`WebSocket server running on port ${WS_PORT}`);
});

app.listen(API_PORT, () => {
  console.log(`API server running on port ${API_PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});

export { app, io };
